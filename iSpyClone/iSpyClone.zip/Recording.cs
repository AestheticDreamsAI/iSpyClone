﻿public class Recording
{
    public string Date {  get; set; }
    public string Time { get; set; }
    public int CameraIndex { get; set; }
    public string Path { get; set; }
    public long Size { get; set; }
}